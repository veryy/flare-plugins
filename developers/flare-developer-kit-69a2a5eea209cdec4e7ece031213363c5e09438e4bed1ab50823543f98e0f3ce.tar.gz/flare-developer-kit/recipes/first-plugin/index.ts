import { definePlugin, PluginError } from '@flare/sdk';

const release = '1.0.0';
const ref = { pluginId: 'flare.developer-guide', id: 'hello', type: 'article' as const, context: { route: 'guide-v1' } };
const summary = { ref, title: '从模板到 flare', author: { id: 'flare', name: 'flare 示例作者' }, excerpt: '搜索 hello，阅读并收藏，再通过网站独立更新插件。' };

export default definePlugin({
  getCapabilities() { return { methods: ['getCapabilities', 'search', 'getDetail'] }; },
  async search({ query, cursor }, host) {
    host.log('info', '教程搜索');
    return { items: !cursor && (query.toLowerCase().includes('hello') || summary.title.includes(query)) ? [summary] : [], nextCursor: null };
  },
  async getDetail(value) {
    if (value.pluginId !== ref.pluginId || value.id !== ref.id || value.type !== ref.type || value.context?.route !== ref.context.route) {
      throw new PluginError('NOT_FOUND', '教程文章引用无效');
    }
    return { ...summary, blocks: [
      { type: 'heading', level: 1, text: '从模板到 flare' },
      { type: 'text', text: `教程插件版本 ${release}` },
      { type: 'text', text: '内容来自独立 JS 插件；页面、搜索与本机收藏由 flare 提供。' },
    ] };
  },
});
