# 从模板开始

这是公开 SDK 开发教程，只提供本地文章，不访问平台、登录或网络。搜索 hello，打开「从模板到 flare」并存到 flare；插件更新后，用原收藏继续打开。

在独立开发包中先执行 `npm run plugin -- new flare.developer-guide plugins/guide`，再用本教程的清单和 TypeScript 源码替换模板。执行 `npm run check`、`npm run plugin -- preview plugins/guide --method search --args '{"query":"hello"}'`，并用 `npm run plugin -- dev plugins/guide` 在本机工作台调试。打包使用 `npm run plugin -- pack plugins/guide`。

发布自己的插件时，把清单 ID／作者和源码引用中的 flare 命名空间改为自己的身份，用自己的私钥签名，并按网站的提交入口交管理员审核。作者私钥不上传。发布 1.1.0 时，同时修改清单版本与源码 release，保持内容 ID 和 route 不变。

下面附有本版本完整清单和源码，可在公开开发包中复现；较新的开发包也在 recipes/first-plugin 提供相同基础教程。只有搜索与阅读能力，不支持首页推荐，这是允许的最小插件。
