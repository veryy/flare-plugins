import { workerData, parentPort } from 'node:worker_threads';
import vm from 'node:vm';
import { createHash } from 'node:crypto';
import { allowsUrl, assertResult } from './protocol.mjs';

const { code, manifest, method, args, storage = {} } = workerData;
const logs = [];
const keepAlive = setInterval(() => {}, 1000);
const storageKey = key => {
  if (typeof key !== 'string' || !key || key.length > 128 || key === '__proto__') throw new Error('存储 key 无效');
  return key;
};
const permission = name => {
  if (!manifest.permissions[name]) throw Object.assign(new Error(`未声明 ${name} 权限`), { code: 'PERMISSION_DENIED' });
};
const host = {
  pluginId: manifest.id,
  accountId: null,
  http: {
    async request(request) {
      if (request.session) throw Object.assign(new Error('账号会话只能在 Android 宿主中调试'), { code: 'LOGIN_REQUIRED' });
      let address = request.url;
      let method = request.method ?? 'GET';
      let body = request.body;
      if (body !== undefined && (typeof body !== 'string' || body.length > 65536)) throw new Error('请求体过大');
      for (let redirects = 0; redirects < 6; redirects += 1) {
        if (!allowsUrl(address, manifest.permissions.domains)) throw Object.assign(new Error('请求域名未获准'), { code: 'PERMISSION_DENIED' });
        const response = await fetch(address, { method, body, headers: request.headers, redirect: 'manual', signal: AbortSignal.timeout(Math.min(request.timeoutMs ?? 10000, 15000)) });
        if ([301, 302, 303, 307, 308].includes(response.status)) {
          const location = response.headers.get('location');
          if (!location) throw new Error('重定向缺少地址');
          await response.body?.cancel();
          address = new URL(location, address).href;
          if (response.status === 303 || ([301, 302].includes(response.status) && method === 'POST')) { method = 'GET'; body = undefined; }
          continue;
        }
        const reader = response.body?.getReader();
        const chunks = [];
        let size = 0;
        if (reader) {
          try {
            while (true) {
              const chunk = await reader.read();
              if (chunk.done) break;
              size += chunk.value.byteLength;
              if (size > 4 * 1024 * 1024) throw new Error('响应体超过 4 MiB');
              chunks.push(Buffer.from(chunk.value));
            }
          } finally { await reader.cancel(); }
        }
        return { status: response.status, headers: Object.fromEntries(response.headers), body: Buffer.concat(chunks).toString('utf8'), url: response.url };
      }
      throw new Error('重定向次数过多');
    },
  },
  storage: {
    async get(key) { permission('storage'); return Object.hasOwn(storage, storageKey(key)) ? storage[key] : null; },
    async set(key, value) { permission('storage'); const next = { ...storage, [storageKey(key)]: value }; if (JSON.stringify(next).length > 65536) throw new Error('开发存储超过 64 KiB'); storage[key] = value; },
    async remove(key) { permission('storage'); delete storage[storageKey(key)]; },
  },
  web: {
    async read() { throw Object.assign(new Error('网页能力需要 Android WebView，请在设备上调试'), { code: 'NOT_SUPPORTED' }); },
    async readPage() { throw Object.assign(new Error('持续网页会话需要 Android WebView，请在设备上调试'), { code: 'NOT_SUPPORTED' }); },
    async closePage() { throw Object.assign(new Error('持续网页会话需要 Android WebView，请在设备上调试'), { code: 'NOT_SUPPORTED' }); },
    async login() { throw Object.assign(new Error('登录需要 Android 宿主'), { code: 'NOT_SUPPORTED' }); },
  },
  tools: {
    async digest({ algorithm, text }) { if (!['SHA-256', 'MD5'].includes(algorithm)) throw new Error('摘要算法无效'); return createHash(algorithm === 'SHA-256' ? 'sha256' : 'md5').update(text).digest('hex'); },
    async base64({ text, decode }) { return decode ? Buffer.from(text, 'base64').toString('utf8') : Buffer.from(text).toString('base64'); },
  },
  log(level, message) { if (logs.length < 100) logs.push({ level, message: String(message).slice(0, 2000) }); },
};

try {
  if (!manifest.capabilities.includes(method)) throw Object.assign(new Error('插件未声明此方法'), { code: 'NOT_SUPPORTED' });
  const context = vm.createContext({ __host: host, __args: args }, { codeGeneration: { strings: false, wasm: false } });
  vm.runInContext(code, context, { timeout: 1000 });
  const invocation = `globalThis.__flarePlugin[${JSON.stringify(method)}](__args, __host)`;
  const result = await vm.runInContext(invocation, context, { timeout: 1000 });
  const parsed = JSON.parse(JSON.stringify(result));
  assertResult(method, parsed, manifest);
  parentPort.postMessage({ ok: true, result: parsed, logs, storage });
} catch (error) {
  parentPort.postMessage({ ok: false, error: { code: error.code ?? 'PLUGIN_ERROR', message: String(error.message) }, logs });
} finally {
  clearInterval(keepAlive);
}
