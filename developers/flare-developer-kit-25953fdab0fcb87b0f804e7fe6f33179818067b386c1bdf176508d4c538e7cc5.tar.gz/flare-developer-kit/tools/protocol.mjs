import { createHash, verify } from 'node:crypto';

export const METHODS = ['getCapabilities', 'resolveUrl', 'getFeed', 'search', 'getDetail', 'getCollectionItems', 'getPlayback', 'getComments', 'getAuthor', 'getAuthorFeed', 'getInteractionState', 'getFavoriteFolders', 'setLike', 'setFavorite', 'setFollow', 'getLoginState', 'login'];
export const MAX_PACKAGE_BYTES = 8 * 1024 * 1024;

export function validateManifest(manifest) {
  const errors = [];
  if (!manifest || typeof manifest !== 'object' || Array.isArray(manifest)) return ['清单必须是对象'];
  if (Buffer.byteLength(JSON.stringify(manifest)) > 16384) errors.push('清单不能超过 16 KiB');
  if (typeof manifest.id !== 'string' || manifest.id.length > 80 || !/^[a-z0-9]+(?:[.-][a-z0-9]+)+$/.test(manifest.id)) errors.push('id 必须使用命名空间，例如 author.source，且不超过 80 个字符');
  for (const key of ['name', 'platform', 'description', 'license']) {
    if (typeof manifest[key] !== 'string' || !manifest[key].trim() || manifest[key].length > 2000) errors.push(`${key} 必须是非空字符串，长度不超过 2000`);
  }
  if (!/^\d+\.\d+\.\d+$/.test(manifest.version ?? '')) errors.push('version 必须是 x.y.z');
  if (manifest.sdkVersion !== 1) errors.push('目前仅支持 sdkVersion: 1');
  if (typeof manifest.author?.id !== 'string' || !/^[a-z0-9][a-z0-9._-]{0,63}$/.test(manifest.author.id)) errors.push('author.id 格式无效');
  if (typeof manifest.author?.name !== 'string' || !manifest.author.name.trim() || manifest.author.name.length > 2000) errors.push('author.name 长度必须在 1–2000 个字符之间');
  if (typeof manifest.entry !== 'string' || !/^[a-zA-Z0-9_-]+\.(?:[cm]?js|ts)$/.test(manifest.entry)) errors.push('entry 必须是项目根目录的 JS／TS 文件');
  if (!Array.isArray(manifest.capabilities) || !manifest.capabilities.includes('getCapabilities') || manifest.capabilities.some(method => !METHODS.includes(method)) || new Set(manifest.capabilities).size !== manifest.capabilities.length) errors.push('capabilities 必须包含 getCapabilities，且不能包含未知或重复方法');
  if (!manifest.permissions || !Array.isArray(manifest.permissions.domains) || manifest.permissions.domains.length > 50 || manifest.permissions.domains.some(domain => typeof domain !== 'string' || !/^(?:\*\.)?(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,63}$/.test(domain))) errors.push('permissions.domains 最多声明 50 项，只接受域名或 *.example.com');
  for (const permission of ['web', 'accounts', 'storage']) {
    if (manifest.permissions?.[permission] !== undefined && typeof manifest.permissions[permission] !== 'boolean') errors.push(`permissions.${permission} 必须是布尔值`);
  }
  if (manifest.demo !== undefined && typeof manifest.demo !== 'boolean') errors.push('demo 必须是布尔值');
  return errors;
}

export function assertManifest(manifest) {
  const errors = validateManifest(manifest);
  if (errors.length) throw new Error(errors.join('\n'));
  return manifest;
}

function assertActions(result) {
  if (result.actions === undefined) return;
  const actions = result.actions;
  if (!actions || typeof actions !== 'object' || Array.isArray(actions) || Object.keys(actions).some(key => !['like', 'favorite', 'follow'].includes(key))) throw new Error('互动权限 actions 无效');
  for (const rule of Object.values(actions)) {
    if (!rule || typeof rule !== 'object' || Array.isArray(rule) || typeof rule.allowed !== 'boolean' ||
        (rule.requiresLogin !== undefined && typeof rule.requiresLogin !== 'boolean') ||
        (rule.reason !== undefined && (typeof rule.reason !== 'string' || rule.reason.length > 2000))) throw new Error('互动权限规则无效');
  }
}

export function allowsUrl(address, domains) {
  let url;
  try { url = new URL(address); } catch { return false; }
  if (url.protocol !== 'https:' || url.username || url.password || (url.port && url.port !== '443')) return false;
  const host = url.hostname.toLowerCase();
  return domains.some(domain => domain.startsWith('*.') ? host.endsWith(domain.slice(1)) && host !== domain.slice(2) : host === domain);
}

export function assertResult(method, result, manifest) {
  const fail = message => { throw new Error(`${method}: ${message}`); };
  const reference = ref => {
    if (!ref || ref.pluginId !== manifest.id || typeof ref.id !== 'string' || !ref.id || !['video', 'image', 'article', 'collection'].includes(ref.type)) fail('内容引用无效或 pluginId 不匹配');
  };
  const summary = item => {
    reference(item?.ref);
    if (typeof item.title !== 'string' || !item.title || typeof item.author?.id !== 'string' || typeof item.author?.name !== 'string') fail('内容摘要缺少标题或作者');
  };
  const folderRef = folder => {
    if (!folder || typeof folder.id !== 'string' || !folder.id.trim() || folder.id.length > 512 ||
        (folder.context !== undefined && (folder.context === null || typeof folder.context !== 'object' || Array.isArray(folder.context) || Buffer.byteLength(JSON.stringify(folder.context)) > 16384))) fail('收藏夹引用无效');
  };
  if (method === 'getFavoriteFolders') {
    if (!Array.isArray(result?.items) || result.items.length > 100 || !(result.nextCursor === null || (typeof result.nextCursor === 'string' && result.nextCursor.trim() && result.nextCursor.length <= 8192)) || Buffer.byteLength(JSON.stringify(result)) > 512 * 1024) fail('收藏夹分页无效');
    const ids = new Set();
    for (const folder of result.items) {
      folderRef(folder);
      if (ids.has(folder.id) || typeof folder.title !== 'string' || !folder.title.trim() || folder.title.length > 2000 || typeof folder.writable !== 'boolean' || !(folder.favorited === null || typeof folder.favorited === 'boolean') || (folder.reason !== undefined && (typeof folder.reason !== 'string' || !folder.reason.trim() || folder.reason.length > 2000))) fail('收藏夹数据无效或 ID 重复');
      ids.add(folder.id);
    }
  } else if (['getFeed', 'search', 'getAuthorFeed', 'getCollectionItems', 'getComments'].includes(method)) {
    if (!Array.isArray(result?.items) || !(result.nextCursor === null || typeof result.nextCursor === 'string')) fail('分页结果必须包含 items 与 nextCursor');
    for (const item of result.items) {
      if (method !== 'getComments') summary(item);
      else {
        const text = (value, limit) => typeof value === 'string' && value.trim().length > 0 && value.length <= limit;
        const context = value => value !== null && typeof value === 'object' && !Array.isArray(value) && Buffer.byteLength(JSON.stringify(value)) <= 16384;
        if (!text(item?.id, 256) || !text(item.text, 32768) || !text(item.author?.id, 512) || !text(item.author?.name, 2000)) fail('评论结构无效');
        if (item.author.avatar !== undefined && (!text(item.author.avatar, 8192) || !allowsUrl(item.author.avatar, manifest.permissions.domains))) fail('评论头像不在授权域名内');
        if ((item.author.description !== undefined && (typeof item.author.description !== 'string' || item.author.description.length > 32768)) || (item.author.url !== undefined && (typeof item.author.url !== 'string' || item.author.url.length > 8192 || !item.author.url.startsWith('https://')))) fail('评论作者资料无效');
        if ((item.context !== undefined && !context(item.context)) || (item.author.context !== undefined && !context(item.author.context))) fail('评论定位上下文无效');
        for (const key of ['likes', 'replyCount', 'publishedAt']) {
          const value = item[key];
          if (value !== undefined && !(key === 'likes' && value === null) && (!Number.isSafeInteger(value) || value < 0)) fail('评论计数或时间无效');
        }
      }
    }
    if (['getComments', 'getCollectionItems'].includes(method) && (result.items.length > 100 || (result.nextCursor !== null && (!result.nextCursor.trim() || result.nextCursor.length > 8192)) || Buffer.byteLength(JSON.stringify(result)) > 512 * 1024)) fail('分页或返回大小无效');
  } else if (method === 'getDetail') {
    summary(result);
    assertActions(result);
    if (!Array.isArray(result.blocks) || result.blocks.length > 500) fail('正文 blocks 无效');
    for (const block of result.blocks) {
      if (!block || !['text', 'heading', 'image', 'quote', 'html', 'video'].includes(block.type)) fail('正文 blocks 无效');
      if (['text', 'heading', 'quote'].includes(block.type) && typeof block.text !== 'string') fail('正文块缺少 text');
      if (block.type === 'heading' && ![1, 2, 3].includes(block.level)) fail('标题级别无效');
      if (block.type === 'html' && typeof block.html !== 'string') fail('HTML 正文无效');
      if (block.type === 'image' && (!allowsUrl(block.url, manifest.permissions.domains) || (block.caption !== undefined && typeof block.caption !== 'string'))) fail('图片地址或说明无效');
      if (block.type === 'video') {
        reference(block.ref);
        if (block.ref.type !== 'video') fail('正文视频必须引用 video 类型内容');
      }
    }
    if (result.episodes !== undefined) {
      if (!Array.isArray(result.episodes) || result.episodes.length > 500) fail('分集目录无效');
      for (const episode of result.episodes) {
        if (typeof episode.title !== 'string' || !episode.title) fail('分集标题无效');
        reference(episode.ref);
      }
    }
  } else if (method === 'getCapabilities') {
    if (!Array.isArray(result?.methods) || result.methods.length !== manifest.capabilities.length || result.methods.some(value => !manifest.capabilities.includes(value)) || new Set(result.methods).size !== result.methods.length) fail('运行时能力必须与清单一致');
  } else if (method === 'getPlayback') {
    if (!Array.isArray(result?.sources) || result.sources.length === 0) fail('缺少播放源');
    for (const source of result.sources) {
      if (typeof source.id !== 'string' || typeof source.title !== 'string' || !allowsUrl(source.url, manifest.permissions.domains) || (source.audioUrl && !allowsUrl(source.audioUrl, manifest.permissions.domains))) fail('播放资源地址不在声明的 HTTPS 域名内');
    }
  } else if (method === 'resolveUrl' && result !== null) reference(result);
  else if (['getLoginState', 'login'].includes(method) && !['loggedIn', 'loggedOut', 'unknown'].includes(result?.status)) fail('登录状态无效');
  else if (['getInteractionState', 'setLike', 'setFavorite', 'setFollow'].includes(method)) {
    assertActions(result);
    for (const key of ['liked', 'favorited', 'followed']) if (result?.[key] !== null && typeof result?.[key] !== 'boolean') fail('互动状态必须是布尔值或 null，不能将未知伪装成未操作');
    if (method === 'setFavorite' && manifest.capabilities.includes('getFavoriteFolders') && !result.favoriteFolder) fail('缺少目标收藏夹确认');
    if (result.favoriteFolder !== undefined) {
      folderRef(result.favoriteFolder);
      if (!(result.favoriteFolder.favorited === null || typeof result.favoriteFolder.favorited === 'boolean')) fail('收藏夹状态必须是布尔值或 null');
    }
  }
  if (JSON.stringify(result)?.length > 1024 * 1024) fail('返回结果超过 1 MiB');
  return result;
}

export function signaturePayload(id, version, sha256) {
  return `flare-plugin-v1\n${id}\n${version}\n${sha256}\n`;
}

export function fingerprint(publicKey) {
  return createHash('sha256').update(publicKey.export({ type: 'spki', format: 'der' })).digest('hex');
}

export function verifyPackage(buffer, signature, publicKey) {
  if (buffer.length > MAX_PACKAGE_BYTES) throw new Error('插件包超过 8 MiB 限制');
  const sha256 = createHash('sha256').update(buffer).digest('hex');
  if (signature.algorithm !== 'RSA-SHA256' || signature.sha256 !== sha256 || signature.keyId !== fingerprint(publicKey)) return false;
  return verify('RSA-SHA256', Buffer.from(signaturePayload(signature.pluginId, signature.version, sha256)), publicKey, Buffer.from(signature.signature, 'base64'));
}
