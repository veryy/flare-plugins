export const SDK_VERSION = 1;

export type ContentType = 'video' | 'image' | 'article' | 'collection';
export type Interaction = 'like' | 'favorite' | 'follow';
export type PluginMethod = keyof FlarePlugin;
export type ErrorCode = 'NETWORK_ERROR' | 'TIMEOUT' | 'CANCELLED' | 'LOGIN_REQUIRED' | 'PERMISSION_DENIED' | 'NOT_SUPPORTED' | 'NOT_FOUND' | 'RATE_LIMITED' | 'INVALID_RESPONSE' | 'INCOMPATIBLE' | 'PLUGIN_ERROR';

export class PluginError extends Error {
  constructor(public code: ErrorCode, message: string, public retryable = false) {
    super(message);
    this.name = 'PluginError';
  }
}

export interface PluginManifest {
  id: string;
  name: string;
  version: string;
  sdkVersion: 1;
  platform: string;
  description: string;
  author: { id: string; name: string; url?: string };
  license: string;
  entry: string;
  capabilities: PluginMethod[];
  permissions: { domains: string[]; web?: boolean; accounts?: boolean; storage?: boolean };
  demo?: boolean;
}

export interface ContentRef {
  pluginId: string;
  id: string;
  type: ContentType;
  url?: string;
  context?: Record<string, unknown>;
}

export interface Author {
  id: string;
  name: string;
  avatar?: string;
  url?: string;
  description?: string;
  context?: Record<string, unknown>;
}

export interface ContentSummary {
  ref: ContentRef;
  title: string;
  author: Author;
  cover?: string;
  excerpt?: string;
  publishedAt?: number;
  stats?: { views?: number | null; likes?: number | null; comments?: number | null };
  tags?: string[];
}

export type ContentBlock =
  | { type: 'text'; text: string }
  | { type: 'heading'; text: string; level: 1 | 2 | 3 }
  | { type: 'image'; url: string; caption?: string; width?: number; height?: number }
  | { type: 'quote'; text: string }
  | { type: 'html'; html: string }
  | { type: 'video'; ref: ContentRef };

export interface ContentDetail extends ContentSummary {
  blocks: ContentBlock[];
  episodes?: { title: string; ref: ContentRef }[];
  attachments?: { title: string; url: string; mimeType?: string }[];
  actions?: Partial<Record<Interaction, { allowed: boolean; requiresLogin?: boolean; reason?: string }>>;
}

export interface Page<T> {
  items: T[];
  nextCursor: string | null;
}

export interface Capabilities {
  methods: readonly PluginMethod[];
  feeds?: readonly { id: string; title: string; requiresLogin?: boolean; kind?: 'discover' | 'following' | 'channel' }[];
  sorts?: { id: string; title: string }[];
  filters?: { id: string; title: string; options: { id: string; title: string }[] }[];
}

export interface PlaybackSource {
  id: string;
  title: string;
  url: string;
  format?: 'mp4' | 'hls' | 'dash' | 'flv' | 'other';
  audioUrl?: string;
  headers?: Record<string, string>;
  expiresAt?: number;
  mimeType?: string;
}

export interface Playback {
  sources: PlaybackSource[];
  subtitles?: { title: string; url: string; mimeType: string; language?: string }[];
}

export interface Comment {
  id: string;
  author: Author;
  text: string;
  publishedAt?: number;
  likes?: number | null;
  replyCount?: number;
  context?: Record<string, unknown>;
}

export interface InteractionState {
  liked: boolean | null;
  favorited: boolean | null;
  followed: boolean | null;
  actions: ContentDetail['actions'];
  /** Required for folder-aware setFavorite; global favorited may remain true in another folder. */
  favoriteFolder?: FavoriteFolderRef & { favorited: boolean | null };
}

export interface FavoriteFolderRef { id: string; context?: Record<string, unknown> }
export interface FavoriteFolder extends FavoriteFolderRef {
  title: string;
  favorited: boolean | null;
  writable: boolean;
  reason?: string;
}

export interface LoginState {
  status: 'loggedIn' | 'loggedOut' | 'unknown';
  accountId?: string;
  displayName?: string;
}

export interface HttpRequest {
  url: string;
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE' | 'HEAD';
  headers?: Record<string, string>;
  body?: string;
  session?: boolean;
  timeoutMs?: number;
}

export interface HttpResponse {
  status: number;
  headers: Record<string, string>;
  body: string;
  url: string;
}

export interface HostContext {
  pluginId: string;
  accountId: string | null;
  http: { request(request: HttpRequest): Promise<HttpResponse> };
  storage: {
    get(key: string): Promise<unknown | null>;
    set(key: string, value: unknown): Promise<void>;
    remove(key: string): Promise<void>;
  };
  web: {
    /** mobile is the default; desktop requests the platform's desktop layout in the same isolated profile. */
    read(request: { url: string; script: string; timeoutMs?: number; viewMode?: 'mobile' | 'desktop' }): Promise<unknown>;
    /** Optional host extension: retain the actual page between reads. Missing on older hosts.
     * Omit pageId to create; subsequent reads must use the same URL and view mode.
     * IDs belong to this plugin package/account, expire after 2 idle or 5 total minutes,
     * and may be evicted. NOT_FOUND means refresh; never silently replay a stale cursor.
     * At most 2 retained pages per host, in addition to 2 transient browsers.
     */
    readPage?(request: { url: string; script: string; pageId?: string; timeoutMs?: number; viewMode?: 'mobile' | 'desktop' }): Promise<{ pageId: string; value: unknown }>;
    /** Release a page promptly. Unknown/expired IDs are safe to close again. */
    closePage?(request: { pageId: string }): Promise<void>;
    login(request: { url: string; title: string; viewMode?: 'mobile' | 'desktop' }): Promise<LoginState>;
  };
  tools: {
    digest(request: { algorithm: 'SHA-256' | 'MD5'; text: string }): Promise<string>;
    base64(request: { text: string; decode?: boolean }): Promise<string>;
  };
  log(level: 'debug' | 'info' | 'warn' | 'error', message: string): void;
}

export interface FeedRequest { feedId?: string; cursor?: string | null }
export interface SearchRequest { query: string; cursor?: string | null; sort?: string; filters?: Record<string, string> }
export interface AuthorRequest { id: string; context?: Record<string, unknown> }

export interface FlarePlugin {
  getCapabilities(): Capabilities | Promise<Capabilities>;
  resolveUrl?(request: { url: string }, host: HostContext): Promise<ContentRef | null>;
  getFeed?(request: FeedRequest, host: HostContext): Promise<Page<ContentSummary>>;
  search?(request: SearchRequest, host: HostContext): Promise<Page<ContentSummary>>;
  getDetail?(ref: ContentRef, host: HostContext): Promise<ContentDetail>;
  getCollectionItems?(request: { ref: ContentRef; cursor?: string | null }, host: HostContext): Promise<Page<ContentSummary>>;
  getPlayback?(ref: ContentRef, host: HostContext): Promise<Playback>;
  getComments?(request: { ref: ContentRef; cursor?: string | null; parentId?: string; context?: Record<string, unknown> }, host: HostContext): Promise<Page<Comment>>;
  getAuthor?(request: AuthorRequest, host: HostContext): Promise<Author>;
  getAuthorFeed?(request: AuthorRequest & { cursor?: string | null }, host: HostContext): Promise<Page<ContentSummary>>;
  getInteractionState?(ref: ContentRef, host: HostContext): Promise<InteractionState>;
  setLike?(request: { ref: ContentRef; value: boolean }, host: HostContext): Promise<InteractionState>;
  getFavoriteFolders?(request: { ref: ContentRef; cursor?: string | null }, host: HostContext): Promise<Page<FavoriteFolder>>;
  setFavorite?(request: { ref: ContentRef; value: boolean; folder?: FavoriteFolderRef }, host: HostContext): Promise<InteractionState>;
  setFollow?(request: { author: AuthorRequest; value: boolean }, host: HostContext): Promise<InteractionState>;
  getLoginState?(request: Record<string, never>, host: HostContext): Promise<LoginState>;
  login?(request: Record<string, never>, host: HostContext): Promise<LoginState>;
}

export function definePlugin<T extends FlarePlugin>(plugin: T): T {
  return plugin;
}

export async function requestJSON<T>(host: HostContext, request: HttpRequest): Promise<T> {
  const response = await host.http.request(request);
  if (response.status === 401 || response.status === 403) throw new PluginError('LOGIN_REQUIRED', `平台拒绝访问（${response.status}）`);
  if (response.status === 429) throw new PluginError('RATE_LIMITED', '平台请求过于频繁，请稍后重试', true);
  if (response.status < 200 || response.status >= 300) throw new PluginError('NETWORK_ERROR', `HTTP ${response.status}`, response.status >= 500);
  try {
    return JSON.parse(response.body) as T;
  } catch {
    throw new PluginError('INVALID_RESPONSE', '平台返回了无法解析的数据');
  }
}

export function queryString(values: Record<string, string | number | boolean | undefined>): string {
  return Object.entries(values).filter(([, value]) => value !== undefined).map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`).join('&');
}
