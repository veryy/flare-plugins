# flare 插件开发包

这个目录是独立的 JS／TS 开发工作区，无需访问 flare App 的私有仓库。需要 Node.js 22 或更新版本。

## 第一次运行

```sh
npm ci
npm run check
npm run plugin -- preview plugins/example-reading --method search --args '{"query":"示例"}'
npm run plugin -- dev plugins/example-reading
```

最后一条命令启动本机网页工作台。示例只返回本地文章，不连接真实平台。工具与 SDK 使用 MIT；安装的 npm 依赖各自保留原许可。

## 创建自己的插件

```sh
npm run plugin -- new yourname.source plugins/my-source
npm run check
npm run plugin -- dev plugins/my-source
```

默认 TypeScript，添加 `--language js` 可使用 JavaScript。修改清单中的名称、平台、作者与许可，按需声明 HTTPS 域名。模板只声明搜索和阅读，空搜索结果需要开发者实现，不代表已经连接平台。类型定义位于 `packages/sdk/src/index.ts`。

插件通过 `host.http.request()` 获取平台数据，并返回 SDK 中的摘要、内容块与稳定引用。宿主决定首页、阅读器和播放器的样式；插件不创建 App 页面。网络、账号、网页和存储只能使用清单声明的宿主能力。使用 `PluginError` 保留平台错误，不能把失败转换成空列表。不要依赖 Node.js、DOM 或全局 `fetch`。

受控网页单次读取使用 `host.web.read`；需要沿用页面变量／滚动位置时，先检查可选的 `host.web.readPage` 和 `host.web.closePage`。首次读取返回 `{ pageId, value }`，后续带同一 `pageId`、入口 URL 和显示模式继续读取，结束后关闭。会话绑定插件包和账号，最多保留两个，空闲两分钟／总存活五分钟或被回收后返回 `NOT_FOUND`，应刷新列表，不能重新开页继续旧游标。取消／超时会释放页面。旧宿主缺少该扩展时明确提示更新；本机工作台不模拟 WebView。不要把页面 ID 当作可持久化的内容引用。

`getFeed`／`search` 返回独立游标，`getDetail` 返回正文，视频另用 `getPlayback` 获取临时资源；收藏保存内容引用。可以只实现搜索与阅读，再按需实现评论、作者、视频或账号。开发工作台用于运行自己信任的开发源码，Android 的受控运行与账号需要安装 App 后验证。

完整教程源码在 `recipes/first-plugin`，从 `new` 命令生成的空模板开始，补齐搜索与详情，再发布 `1.0.0`／`1.1.0` 两个版本。官网的[从模板开始](https://veryy.github.io/flare-plugins/plugins/flare.developer-guide/)提供对应签名包、版本记录与完整源码说明。它只返回本地文章，不连接真实平台。发布自己的版本时，请替换清单 ID／作者、源码中的 `pluginId` 和自己的签名密钥；flare 命名空间属于官方教程，不能用来冒充发布者。

正文中可返回 `{ type: 'video', ref: { pluginId: '你的插件 ID', id: '独立视频 ID', type: 'video', context: {} } }`。子引用必须属于原插件且类型为 `video`，其上下文原样传给播放和详情接口。Android 点按且网络允许时才调用 `getPlayback`；离屏或被其他面板覆盖会释放播放器，返回后可能重新解析并续播。不要把父文章身份或临时媒体 URL 当作子视频 ID。开发工具会拒绝类型错误的正文视频引用。

平台互动独立于 App 本机收藏。按内容返回 `actions`，例如 `{ like: { allowed: true, requiresLogin: true } }`；仅支持 `like`／`favorite`／`follow`，`allowed` 与可选 `requiresLogin` 必须为布尔值，可选 `reason` 最多 2000 字符。声明方法不代表每条内容都允许操作。互动接口返回完整 `liked`／`favorited`／`followed`，未知用 `null`；写入时使用明确的 `value: true/false`，返回平台确认的实际状态。App 不自动重试写操作，超时后先重新查询；账号状态按 `host.accountId` 隔离。`setFollow` 的作者上下文不能用作品上下文替代。

Android 当前限制构建后的 JS 为 2 MiB、每次调用 JS 堆为 32 MiB、单次返回及轮询 JSON 为 512 KiB（包含封装，按 UTF-8 字节计算）；请分页并为正文和多字节字符预留空间。超过返回限制会得到 `INVALID_RESPONSE`，不要转换为空内容。全进程最多同时执行三个调用，排队可取消；普通方法执行最多 20 秒，登录最多 300 秒，每次原生求值最多 2 秒。

JS 堆限制不等于整个进程的 RSS 上限。内存超限可能终止共享沙箱，其他受影响调用明确失败；后续显式请求可重连，宿主不会自动重放已经接受的写操作。写操作结果不明时先重新查询。网页能力另有独立限制，完整限制与设备证据见 App 仓库开发指南。

## 签名与提交

集合来源可选实现 `getCollectionItems({ ref, cursor }, host)`，并在清单与能力声明中加入该方法。`ref` 是稳定的集合引用，子项返回标准内容摘要，下一页仍传原集合引用和原游标；首次不传游标，结束返回 `nextCursor: null`。每页最多 100 条、512 KiB，游标非空且不超过 8192 字符。宿主统一提供目录、追加、重试与子内容返回，不需要插件创建界面；需要支持此可选方法的新版 App。

```sh
npm run plugin -- keygen
npm run plugin -- pack plugins/my-source
```

把 `dist` 中的 `.flare-plugin`、对应 `.signature.json`、作者公钥（`.flare/keys/author.public.pem`）、分类和版本说明提交到网站的“提交插件”入口。可以提供公开 HTTPS 下载地址。作者私钥留在本机，不上传、也不随包分发；公钥不等于自动获得目录信任。新版本保持插件 ID／作者身份不变并递增版本号。

在提供「从文件导入插件」入口的 Android App 中，也可先安装自己的签名包验证：进入「我的 → 管理插件 → 从文件导入插件」，分别选择插件包、签名 JSON 和作者公钥，核对指纹及权限后安装。只在安装确认后执行能力声明检查。网站插件详情同样提供三种文件下载；作者公钥不是连接目录所用的根公钥。更新沿用相同作者密钥并提升版本，权限变化需确认；保存的稳定引用可在更新／回滚后继续使用。文件导入不替代网站对作者身份的审核。

第一版通过 GitHub Issue 接收提交，由管理员核实发布者身份、登记公钥并检查签名后发布；提交不会自动执行或上线。发布后的版本和下载摘要展示在网站，App 从同一签名目录安装和独立更新。故障也通过网站“问题反馈”入口提交，避免包含账号、Cookie 或带签名参数的媒体地址。

示例插件 ID `example.reading` 只供本地调试；发布自己的插件请使用自己的作者命名空间。签名证明包由对应私钥签署且内容完整；作者身份仍需核对，安装时需要用户确认域名与权限。

## 开发包校验

下载后先使用网站列出的 SHA-256 校验压缩包。`KIT.json` 记录开发包格式、SDK 版本、来源提交及每个文件的摘要。开发包通过显式文件清单构建，包含 SDK、工具、锁文件、这个指南、本地阅读示例和完整教程源码，不包含 App 源码、账号或发布密钥。
