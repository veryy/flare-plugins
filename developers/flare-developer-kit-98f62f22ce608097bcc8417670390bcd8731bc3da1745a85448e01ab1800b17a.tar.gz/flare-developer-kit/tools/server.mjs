import http from 'node:http';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { resolve } from 'node:path';
import { buildPlugin, root } from './build.mjs';
import { runPreview } from './preview.mjs';

const page = `<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>flare 插件工作台</title>
<style>body{background:#090b10;color:#f0f3f6;font:15px system-ui;max-width:1080px;margin:auto;padding:32px}h1{font-size:32px}small,p{color:#9ca5af}main{display:grid;grid-template-columns:1fr 1.3fr;gap:24px}section{background:#151920;border-radius:18px;padding:24px}select,textarea,button{box-sizing:border-box;width:100%;padding:12px;border-radius:10px;border:1px solid #343b43;background:#090b10;color:#fff;font:14px monospace;margin:10px 0}textarea{min-height:220px;resize:vertical}button{background:#bdf76a;color:#090b10;cursor:pointer;font-weight:bold}pre{white-space:pre-wrap;overflow-wrap:anywhere;max-height:70vh;overflow:auto;font-size:12px}a{color:#bdf76a}@media(max-width:700px){main{grid-template-columns:1fr}body{padding:16px}}</style>
<h1>flare<span style="color:#bdf76a">.</span> 插件工作台</h1><p id="identity">加载插件清单…</p><small>本地工作台运行你正在开发的可信代码；账号及 WebView 能力请在 Android 宿主调试。</small>
<main><section><h2>调用接口</h2><label>方法<select id="method"></select></label><label>参数 JSON<textarea id="args">{}</textarea></label><button id="run">构建并运行</button><p id="state">每次运行都会重新构建源码。</p><h3>声明与权限</h3><pre id="manifest"></pre></section><section><h2>数据与日志</h2><pre id="result">运行接口后查看标准数据、分页游标与结构化错误。</pre></section></main>
<script type="module">const $=id=>document.getElementById(id);const manifest=await(await fetch('/api/manifest')).json();$('identity').textContent=manifest.name+' · '+manifest.id+'@'+manifest.version;$('manifest').textContent=JSON.stringify(manifest,null,2);for(const method of manifest.capabilities){const option=document.createElement('option');option.value=method;option.textContent=method;$('method').append(option)}$('method').onchange=()=>{$('args').value=JSON.stringify($('method').value==='search'?{query:'生活'}:{},null,2)};$('run').onclick=async()=>{try{$('run').disabled=true;$('state').textContent='构建与执行中…';const response=await fetch('/api/run',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({method:$('method').value,args:JSON.parse($('args').value)})});const data=await response.json();$('result').textContent=JSON.stringify(data,null,2);$('state').textContent=data.ok?'执行成功':'执行失败，查看结构化错误'}catch(error){$('state').textContent=error.message}finally{$('run').disabled=false}};</script></html>`;

export async function startDevServer(directory, port = 4174) {
  if (!Number.isInteger(port) || port < 0 || port > 65535) throw new Error('端口无效');
  const initial = await buildPlugin(directory);
  const storageDirectory = resolve(root, '.flare/dev-storage');
  await mkdir(storageDirectory, { recursive: true });
  const storagePath = resolve(storageDirectory, `${initial.manifest.id}.json`);
  let storage = {};
  try { storage = JSON.parse(await readFile(storagePath, 'utf8')); } catch (error) { if (error.code !== 'ENOENT') throw error; }
  let running = false;
  const server = http.createServer(async (request, response) => {
    const address = server.address();
    const allowedHosts = [`127.0.0.1:${address.port}`, `localhost:${address.port}`];
    const json = (status, data) => { response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }); response.end(JSON.stringify(data)); };
    if (!allowedHosts.includes(request.headers.host)) return json(403, { error: 'Host 不匹配' });
    if (request.headers.origin && !allowedHosts.some(host => request.headers.origin === `http://${host}`)) return json(403, { error: '不允许跨站调用' });
    try {
      if (request.url === '/' && request.method === 'GET') {
        response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
        response.end(page);
      } else if (request.url === '/api/manifest' && request.method === 'GET') {
        json(200, (await buildPlugin(directory)).manifest);
      } else if (request.url === '/api/run' && request.method === 'POST') {
        if (!request.headers['content-type']?.startsWith('application/json')) return json(415, { error: '需要 JSON 请求' });
        if (running) return json(409, { error: '已有接口正在执行' });
        running = true;
        try {
          let size = 0;
          const chunks = [];
          for await (const chunk of request) { size += chunk.length; if (size > 65536) throw new Error('请求体超过 64 KiB'); chunks.push(chunk); }
          const body = JSON.parse(Buffer.concat(chunks).toString('utf8'));
          const plugin = await buildPlugin(directory);
          if (plugin.manifest.id !== initial.manifest.id) throw new Error('修改插件 ID 后请重启工作台');
          const result = await runPreview(plugin, body.method, body.args ?? {}, { storage });
          if (result.ok) { storage = result.storage; await writeFile(storagePath, JSON.stringify(storage)); }
          json(200, result);
        } finally { running = false; }
      } else json(404, { error: '没有此接口' });
    } catch (error) { json(400, { ok: false, error: { code: 'DEV_ERROR', message: error.message } }); }
  });
  await new Promise((resolveReady, reject) => { server.once('error', reject); server.listen(port, '127.0.0.1', resolveReady); });
  console.log(`插件工作台：http://127.0.0.1:${server.address().port}`);
  return server;
}
