import { inflateRawSync } from 'node:zlib';
import { MAX_PACKAGE_BYTES } from './protocol.mjs';

function crc32(buffer) {
  let result = 0xffffffff;
  for (const byte of buffer) {
    result ^= byte;
    for (let bit = 0; bit < 8; bit += 1) result = (result >>> 1) ^ (0xedb88320 & -(result & 1));
  }
  return (result ^ 0xffffffff) >>> 0;
}

function safeName(name) {
  if (!/^[A-Za-z0-9_.-]+$/.test(name) || name === '.' || name === '..') throw new Error('插件包只允许根目录文件，禁止路径穿越');
}

export function createZip(files) {
  const local = [];
  const directory = [];
  let offset = 0;
  for (const [filename, value] of Object.entries(files)) {
    safeName(filename);
    const name = Buffer.from(filename);
    const body = Buffer.from(value);
    const crc = crc32(body);
    const header = Buffer.alloc(30);
    header.writeUInt32LE(0x04034b50);
    header.writeUInt16LE(20, 4);
    header.writeUInt16LE(33, 12);
    header.writeUInt32LE(crc, 14);
    header.writeUInt32LE(body.length, 18);
    header.writeUInt32LE(body.length, 22);
    header.writeUInt16LE(name.length, 26);
    local.push(header, name, body);
    const entry = Buffer.alloc(46);
    entry.writeUInt32LE(0x02014b50);
    entry.writeUInt16LE(20, 4);
    entry.writeUInt16LE(20, 6);
    entry.writeUInt16LE(33, 14);
    entry.writeUInt32LE(crc, 16);
    entry.writeUInt32LE(body.length, 20);
    entry.writeUInt32LE(body.length, 24);
    entry.writeUInt16LE(name.length, 28);
    entry.writeUInt32LE(offset, 42);
    directory.push(entry, name);
    offset += header.length + name.length + body.length;
  }
  const central = Buffer.concat(directory);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50);
  end.writeUInt16LE(Object.keys(files).length, 8);
  end.writeUInt16LE(Object.keys(files).length, 10);
  end.writeUInt32LE(central.length, 12);
  end.writeUInt32LE(offset, 16);
  const result = Buffer.concat([...local, central, end]);
  if (result.length > MAX_PACKAGE_BYTES) throw new Error('插件包超过 8 MiB 限制');
  return result;
}

export function readZip(buffer) {
  if (buffer.length > MAX_PACKAGE_BYTES || buffer.length < 22) throw new Error('插件包大小无效');
  const files = Object.create(null);
  const records = new Map();
  let offset = 0;
  let expanded = 0;
  while (offset + 4 <= buffer.length && buffer.readUInt32LE(offset) === 0x04034b50) {
    if (offset + 30 > buffer.length) throw new Error('ZIP 文件头不完整');
    const flags = buffer.readUInt16LE(offset + 6);
    const compression = buffer.readUInt16LE(offset + 8);
    const crc = buffer.readUInt32LE(offset + 14);
    const compressedSize = buffer.readUInt32LE(offset + 18);
    const uncompressedSize = buffer.readUInt32LE(offset + 22);
    const nameSize = buffer.readUInt16LE(offset + 26);
    const extraSize = buffer.readUInt16LE(offset + 28);
    const name = buffer.subarray(offset + 30, offset + 30 + nameSize).toString('utf8');
    safeName(name);
    if (flags !== 0 || ![0, 8].includes(compression) || Object.hasOwn(files, name)) throw new Error('不支持的 ZIP 标志、压缩方式或重复文件');
    const start = offset + 30 + nameSize + extraSize;
    if (start + compressedSize > buffer.length || expanded + uncompressedSize > MAX_PACKAGE_BYTES) throw new Error('ZIP 数据越界或解压后体积过大');
    const compressed = buffer.subarray(start, start + compressedSize);
    const body = compression === 0 ? compressed : inflateRawSync(compressed, { maxOutputLength: MAX_PACKAGE_BYTES - expanded });
    if (body.length !== uncompressedSize || crc32(body) !== crc) throw new Error('ZIP 长度或 CRC 校验失败');
    files[name] = body;
    records.set(name, { offset, crc, compressedSize, uncompressedSize, compression });
    expanded += body.length;
    if (Object.keys(files).length > 32) throw new Error('插件包文件过多');
    offset = start + compressedSize;
  }
  const centralStart = offset;
  const directoryNames = new Set();
  while (offset + 46 <= buffer.length && buffer.readUInt32LE(offset) === 0x02014b50) {
    const nameSize = buffer.readUInt16LE(offset + 28);
    const extraSize = buffer.readUInt16LE(offset + 30);
    const commentSize = buffer.readUInt16LE(offset + 32);
    const name = buffer.subarray(offset + 46, offset + 46 + nameSize).toString('utf8');
    const entry = records.get(name);
    if (!entry || directoryNames.has(name) || buffer.readUInt16LE(offset + 8) !== 0 || buffer.readUInt16LE(offset + 10) !== entry.compression || buffer.readUInt32LE(offset + 16) !== entry.crc || buffer.readUInt32LE(offset + 20) !== entry.compressedSize || buffer.readUInt32LE(offset + 24) !== entry.uncompressedSize || buffer.readUInt16LE(offset + 34) !== 0 || buffer.readUInt32LE(offset + 42) !== entry.offset) throw new Error('ZIP 中央目录与文件数据不一致');
    directoryNames.add(name);
    offset += 46 + nameSize + extraSize + commentSize;
  }
  if (offset + 22 > buffer.length || buffer.readUInt32LE(offset) !== 0x06054b50 || offset + 22 + buffer.readUInt16LE(offset + 20) !== buffer.length || buffer.readUInt16LE(offset + 4) !== 0 || buffer.readUInt16LE(offset + 6) !== 0 || buffer.readUInt16LE(offset + 8) !== records.size || buffer.readUInt16LE(offset + 10) !== records.size || buffer.readUInt32LE(offset + 12) !== offset - centralStart || buffer.readUInt32LE(offset + 16) !== centralStart || directoryNames.size !== records.size) throw new Error('ZIP 目录缺失或结束记录无效');
  if (!files['manifest.json'] || !files['index.js']) throw new Error('插件包缺少 manifest.json 或 index.js');
  return files;
}
