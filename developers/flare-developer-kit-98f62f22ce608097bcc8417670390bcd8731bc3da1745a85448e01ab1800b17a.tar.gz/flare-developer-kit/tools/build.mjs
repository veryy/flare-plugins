import { build } from 'esbuild';
import { readFile, mkdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { assertManifest } from './protocol.mjs';

export const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');

export async function buildPlugin(directory) {
  const source = resolve(directory);
  const manifest = assertManifest(JSON.parse(await readFile(resolve(source, 'manifest.json'), 'utf8')));
  const output = resolve(root, '.flare/build', manifest.id, manifest.version);
  await mkdir(output, { recursive: true });
  await build({
    entryPoints: [resolve(source, manifest.entry)],
    bundle: true,
    platform: 'browser',
    format: 'iife',
    globalName: 'FlarePluginBundle',
    target: 'es2020',
    outfile: resolve(output, 'index.js'),
    alias: { '@flare/sdk': resolve(root, 'packages/sdk/src/index.ts') },
    footer: { js: 'globalThis.__flarePlugin = FlarePluginBundle.default;' },
    logLevel: 'silent',
  });
  return { manifest, output, source, code: await readFile(resolve(output, 'index.js'), 'utf8') };
}
