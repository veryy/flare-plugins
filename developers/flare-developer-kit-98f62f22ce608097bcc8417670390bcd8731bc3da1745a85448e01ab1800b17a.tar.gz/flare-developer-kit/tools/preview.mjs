import { Worker } from 'node:worker_threads';

export function runPreview(plugin, method, args = {}, { timeoutMs = 15000, storage = {} } = {}) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const worker = new Worker(new URL('./preview-worker.mjs', import.meta.url), {
      workerData: { code: plugin.code, manifest: plugin.manifest, method, args, storage },
      resourceLimits: { maxOldGenerationSizeMb: 64, maxYoungGenerationSizeMb: 16, stackSizeMb: 4 },
    });
    const timer = setTimeout(() => {
      settled = true;
      void worker.terminate();
      reject(new Error('插件预览超时'));
    }, timeoutMs);
    worker.once('message', result => { settled = true; clearTimeout(timer); void worker.terminate(); resolve(result); });
    worker.once('error', error => { settled = true; clearTimeout(timer); reject(error); });
    worker.once('exit', code => { clearTimeout(timer); if (!settled) reject(new Error(`插件预览进程未返回结果：${code}`)); });
  });
}
