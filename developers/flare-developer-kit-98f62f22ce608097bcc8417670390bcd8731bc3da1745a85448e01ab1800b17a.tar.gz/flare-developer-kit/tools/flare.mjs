import { createHash, createPublicKey, generateKeyPairSync, sign } from 'node:crypto';
import { readFile, writeFile, mkdir, access } from 'node:fs/promises';
import { resolve } from 'node:path';
import { buildPlugin, root } from './build.mjs';
import { fingerprint, signaturePayload, assertManifest } from './protocol.mjs';
import { createZip } from './zip.mjs';
import { runPreview } from './preview.mjs';

const [command, ...args] = process.argv.slice(2);
const option = name => { const index = args.indexOf(name); return index < 0 ? undefined : args[index + 1]; };

async function main() {
  if (command === 'new') {
    const id = args[0];
    if (!/^[a-z0-9]+(?:[.-][a-z0-9]+)+$/.test(id ?? '')) throw new Error('用法：npm run plugin -- new author.source plugins/source [--language js]');
    const directory = resolve(args[1] ?? `plugins/${id}`);
    try { await access(directory); throw new Error('目标目录已存在，不覆盖现有文件'); } catch (error) { if (error.code !== 'ENOENT') throw error; }
    await mkdir(directory, { recursive: true });
    const extension = option('--language') === 'js' ? 'js' : 'ts';
    const manifest = { id, name: id, version: '1.0.0', sdkVersion: 1, platform: id, description: '请填写来源及功能说明', author: { id: id.split(/[.-]/)[0], name: '请填写作者' }, license: 'UNLICENSED', entry: `index.${extension}`, capabilities: ['getCapabilities', 'search', 'getDetail'], permissions: { domains: [], storage: true } };
    const entry = `import { definePlugin, PluginError } from '@flare/sdk';\n\nexport default definePlugin({\n  getCapabilities() { return { methods: ['getCapabilities', 'search', 'getDetail'] }; },\n  async search({ query }, host) {\n    host.log('info', '搜索：' + query);\n    return { items: [], nextCursor: null };\n  },\n  async getDetail(ref) { throw new PluginError('NOT_FOUND', '请实现详情：' + ref.id); },\n});\n`;
    await writeFile(resolve(directory, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
    await writeFile(resolve(directory, `index.${extension}`), entry);
    await writeFile(resolve(directory, 'README.md'), `# ${id}\n\n这是开发模板，尚未连接真实平台。先实现 search 和 getDetail，再按需添加能力。\n`);
    console.log(directory);
  } else if (command === 'keygen') {
    const output = resolve(option('--out') ?? resolve(root, '.flare/keys/author'));
    await mkdir(resolve(output, '..'), { recursive: true, mode: 0o700 });
    const keys = generateKeyPairSync('rsa', { modulusLength: 3072, publicKeyEncoding: { type: 'spki', format: 'pem' }, privateKeyEncoding: { type: 'pkcs8', format: 'pem' } });
    await writeFile(`${output}.private.pem`, keys.privateKey, { mode: 0o600, flag: 'wx' });
    await writeFile(`${output}.public.pem`, keys.publicKey, { flag: 'wx' });
    console.log('公钥指纹：' + fingerprint(createPublicKey(keys.publicKey)));
    console.log('公钥：' + `${output}.public.pem`);
  } else if (['check', 'build', 'pack', 'preview', 'dev'].includes(command)) {
    if (!args[0]) throw new Error('请提供插件目录');
    const plugin = await buildPlugin(args[0]);
    if (command === 'preview') {
      const response = await runPreview(plugin, option('--method') ?? 'getCapabilities', JSON.parse(option('--args') ?? '{}'));
      console.log(JSON.stringify(response, null, 2));
      if (!response.ok) process.exitCode = 1;
    } else if (command === 'dev') {
      const { startDevServer } = await import('./server.mjs');
      await startDevServer(plugin.source, Number(option('--port') ?? 4174));
    } else if (command === 'pack') {
      const keyPath = resolve(option('--key') ?? resolve(root, '.flare/keys/author.private.pem'));
      const key = await readFile(keyPath, 'utf8');
      const publicKey = createPublicKey(key);
      const manifest = assertManifest({ ...plugin.manifest, entry: 'index.js' });
      const files = { 'manifest.json': JSON.stringify(manifest), 'index.js': plugin.code };
      for (const name of ['README.md', 'LICENSE', 'NOTICE', 'icon.png']) {
        try { files[name] = await readFile(resolve(plugin.source, name)); } catch (error) { if (error.code !== 'ENOENT') throw error; }
      }
      const archive = createZip(files);
      const sha256 = createHash('sha256').update(archive).digest('hex');
      const signature = { algorithm: 'RSA-SHA256', pluginId: manifest.id, version: manifest.version, sha256, keyId: fingerprint(publicKey), signature: sign('RSA-SHA256', Buffer.from(signaturePayload(manifest.id, manifest.version, sha256)), key).toString('base64') };
      const output = resolve(option('--out') ?? resolve(root, 'dist', `${manifest.id}-${manifest.version}.flare-plugin`));
      await mkdir(resolve(output, '..'), { recursive: true });
      await writeFile(output, archive);
      await writeFile(`${output}.signature.json`, JSON.stringify(signature, null, 2) + '\n');
      console.log(output);
    } else {
      console.log(`${plugin.manifest.id}@${plugin.manifest.version}：清单校验与构建通过，输出 ${plugin.output}`);
    }
  } else {
    console.log('flare 插件工具：\n  new author.source plugins/source [--language js]\n  check plugins/source\n  build plugins/source\n  preview plugins/source [--method search --args \'{"query":"咖啡"}\']\n  dev plugins/source [--port 4174]\n  keygen [--out .flare/keys/author]\n  pack plugins/source [--key .flare/keys/author.private.pem] [--out dist/source.flare-plugin]');
    if (command) process.exitCode = 1;
  }
}

main().catch(error => { console.error(error.message); process.exitCode = 1; });
