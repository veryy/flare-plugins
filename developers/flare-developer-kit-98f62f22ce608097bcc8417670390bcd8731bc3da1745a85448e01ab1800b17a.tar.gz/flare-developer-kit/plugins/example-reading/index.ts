import { definePlugin, PluginError } from '@flare/sdk';
const ref = { pluginId: 'example.reading', id: 'hello', type: 'article' as const };
const summary = { ref, title: '我的第一篇示例', author: { id: 'example', name: '示例作者' }, excerpt: '本地数据，用于调试插件协议。' };
export default definePlugin({
  getCapabilities() { return { methods: ['getCapabilities', 'search', 'getDetail'] }; },
  async search({ query, cursor }, host) {
    host.log('info', '本地示例搜索');
    return { items: !cursor && summary.title.includes(query) ? [summary] : [], nextCursor: null };
  },
  async getDetail(value) {
    if (value.pluginId !== ref.pluginId || value.id !== ref.id || value.type !== ref.type) throw new PluginError('NOT_FOUND', '示例文章不存在');
    return { ...summary, blocks: [{ type: 'text', text: '插件提供内容，flare 负责统一展示。' }] };
  },
});
