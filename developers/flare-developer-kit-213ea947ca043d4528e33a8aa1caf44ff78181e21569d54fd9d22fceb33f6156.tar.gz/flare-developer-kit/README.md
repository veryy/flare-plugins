# flare 插件开发包

这个目录是独立的 JS／TS 开发工作区，无需访问 flare App 的私有仓库。需要 Node.js 22 或更新版本。

## 第一次运行

```sh
npm ci
npm run check
npm run plugin -- preview plugins/example-reading --method search --args '{"query":"示例"}'
npm run plugin -- dev plugins/example-reading
```

最后一条命令启动本机网页工作台。示例只返回本地文章，不连接真实平台。工具与 SDK 使用 MIT；安装的 npm 依赖各自保留原许可。

## 创建自己的插件

```sh
npm run plugin -- new yourname.source plugins/my-source
npm run check
npm run plugin -- dev plugins/my-source
```

默认 TypeScript，添加 `--language js` 可使用 JavaScript。修改清单中的名称、平台、作者与许可，按需声明 HTTPS 域名。模板只声明搜索和阅读，空搜索结果需要开发者实现，不代表已经连接平台。类型定义位于 `packages/sdk/src/index.ts`。

插件通过 `host.http.request()` 获取平台数据，并返回 SDK 中的摘要、内容块与稳定引用。宿主决定首页、阅读器和播放器的样式；插件不创建 App 页面。网络、账号、网页和存储只能使用清单声明的宿主能力。使用 `PluginError` 保留平台错误，不能把失败转换成空列表。不要依赖 Node.js、DOM 或全局 `fetch`。

`getFeed`／`search` 返回独立游标，`getDetail` 返回正文，视频另用 `getPlayback` 获取临时资源；收藏保存内容引用。可以只实现搜索与阅读，再按需实现评论、作者、视频或账号。开发工作台用于运行自己信任的开发源码，Android 的受控运行与账号需要安装 App 后验证。

正文中可返回 `{ type: 'video', ref: { pluginId: '你的插件 ID', id: '独立视频 ID', type: 'video', context: {} } }`。子引用必须属于原插件且类型为 `video`，其上下文原样传给播放和详情接口。Android 点按且网络允许时才调用 `getPlayback`；离屏或被其他面板覆盖会释放播放器，返回后可能重新解析并续播。不要把父文章身份或临时媒体 URL 当作子视频 ID。开发工具会拒绝类型错误的正文视频引用。

## 签名与提交

```sh
npm run plugin -- keygen
npm run plugin -- pack plugins/my-source
```

把 `dist` 中的 `.flare-plugin`、对应 `.signature.json`、作者公钥（`.flare/keys/author.public.pem`）、分类和版本说明提交到网站的“提交插件”入口。可以提供公开 HTTPS 下载地址。作者私钥留在本机，不上传、也不随包分发；公钥不等于自动获得目录信任。新版本保持插件 ID／作者身份不变并递增版本号。

第一版通过 GitHub Issue 接收提交，由管理员核实发布者身份、登记公钥并检查签名后发布；提交不会自动执行或上线。发布后的版本和下载摘要展示在网站，App 从同一签名目录安装和独立更新。故障也通过网站“问题反馈”入口提交，避免包含账号、Cookie 或带签名参数的媒体地址。

示例插件 ID `example.reading` 只供本地调试；发布自己的插件请使用自己的作者命名空间。签名只能证明作者与包完整性，安装时仍需要用户确认域名与权限。

## 开发包校验

下载后先使用网站列出的 SHA-256 校验压缩包。`KIT.json` 记录开发包格式、SDK 版本、来源提交及每个文件的摘要。开发包通过显式文件清单构建，包含 SDK、工具、锁文件、这个指南和本地阅读示例，不包含 App 源码、账号或发布密钥。
